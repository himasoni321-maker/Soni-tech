package com.assistant.overlay;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_CODE_OVERLAY_PERMISSION = 1001;

    private TextView tvPermissionStatus;
    private TextView tvServiceStatus;
    private Button btnRequestPermission;
    private Button btnToggleService;
    private Button btnTestOverlay;

    // Activity Result Launcher for modern Android 13+ Notification Permission
    private final ActivityResultLauncher<String> notificationPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    Toast.makeText(this, "Notification permission granted", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Foreground service notification disabled", Toast.LENGTH_SHORT).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        setupListeners();
        checkNotificationPermission();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateUIState();
    }

    private void initViews() {
        tvPermissionStatus = findViewById(R.id.tvPermissionStatus);
        tvServiceStatus = findViewById(R.id.tvServiceStatus);
        btnRequestPermission = findViewById(R.id.btnRequestPermission);
        btnToggleService = findViewById(R.id.btnToggleService);
        btnTestOverlay = findViewById(R.id.btnTestOverlay);
    }

    private void setupListeners() {
        btnRequestPermission.setOnClickListener(v -> requestOverlayPermission());

        btnToggleService.setOnClickListener(v -> {
            if (!hasOverlayPermission()) {
                Toast.makeText(this, "Please grant Overlay Permission first", Toast.LENGTH_SHORT).show();
                requestOverlayPermission();
                return;
            }

            if (FloatingService.isRunning()) {
                stopFloatingService();
            } else {
                startFloatingService();
            }
            updateUIState();
        });

        btnTestOverlay.setOnClickListener(v -> {
            if (!hasOverlayPermission()) {
                Toast.makeText(this, "Overlay permission is required", Toast.LENGTH_SHORT).show();
                return;
            }
            // Launch Home screen or external browser to show overlay hovering over other apps
            Intent homeIntent = new Intent(Intent.ACTION_MAIN);
            homeIntent.addCategory(Intent.CATEGORY_HOME);
            homeIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(homeIntent);
        });
    }

    /**
     * Checks if the app has permission to draw on top of other apps (SYSTEM_ALERT_WINDOW).
     */
    private boolean hasOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return Settings.canDrawOverlays(this);
        }
        return true; // Granted automatically on API < 23
    }

    /**
     * Guides the user to system settings to grant "Display over other apps".
     */
    private void requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())
                );
                startActivityForResult(intent, REQUEST_CODE_OVERLAY_PERMISSION);
            } else {
                Toast.makeText(this, "Overlay permission already granted!", Toast.LENGTH_SHORT).show();
                updateUIState();
            }
        }
    }

    /**
     * Handles returning from Settings screen.
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_OVERLAY_PERMISSION) {
            if (hasOverlayPermission()) {
                Toast.makeText(this, "Permission Granted! You can now start the assistant.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Permission Denied. Floating assistant cannot display.", Toast.LENGTH_LONG).show();
            }
            updateUIState();
        }
    }

    private void checkNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS);
            }
        }
    }

    private void startFloatingService() {
        Intent serviceIntent = new Intent(this, FloatingService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent);
        } else {
            startService(serviceIntent);
        }
        Toast.makeText(this, "Floating Assistant Started", Toast.LENGTH_SHORT).show();
    }

    private void stopFloatingService() {
        Intent serviceIntent = new Intent(this, FloatingService.class);
        stopService(serviceIntent);
        Toast.makeText(this, "Floating Assistant Stopped", Toast.LENGTH_SHORT).show();
    }

    private void updateUIState() {
        boolean hasPermission = hasOverlayPermission();
        boolean isServiceRunning = FloatingService.isRunning();

        if (hasPermission) {
            tvPermissionStatus.setText("Overlay Permission: GRANTED");
            tvPermissionStatus.setTextColor(ContextCompat.getColor(this, R.color.status_granted));
            btnRequestPermission.setEnabled(false);
            btnRequestPermission.setText("Permission Granted");
        } else {
            tvPermissionStatus.setText("Overlay Permission: MISSING");
            tvPermissionStatus.setTextColor(ContextCompat.getColor(this, R.color.status_missing));
            btnRequestPermission.setEnabled(true);
            btnRequestPermission.setText("Grant Overlay Permission");
        }

        if (isServiceRunning) {
            tvServiceStatus.setText("Assistant State: ACTIVE (Floating on screen)");
            tvServiceStatus.setTextColor(ContextCompat.getColor(this, R.color.status_granted));
            btnToggleService.setText("Stop Floating Assistant");
            btnToggleService.setBackgroundColor(ContextCompat.getColor(this, R.color.btn_danger));
            btnTestOverlay.setVisibility(View.VISIBLE);
        } else {
            tvServiceStatus.setText("Assistant State: STOPPED");
            tvServiceStatus.setTextColor(ContextCompat.getColor(this, R.color.text_secondary));
            btnToggleService.setText("Start Floating Assistant");
            btnToggleService.setBackgroundColor(ContextCompat.getColor(this, R.color.primary));
            btnTestOverlay.setVisibility(View.GONE);
        }
    }
}