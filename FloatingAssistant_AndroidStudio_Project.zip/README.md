# Native Android Floating Assistant (SYSTEM_ALERT_WINDOW)

A production-ready Android Studio native Java project that creates a system-wide floating overlay widget using `WindowManager` and a persistent `ForegroundService`.

## Architecture Overview

1. **System Alert Window Permission (`SYSTEM_ALERT_WINDOW`)**:
   - `MainActivity.java` checks `Settings.canDrawOverlays(this)`.
   - Directs users to `Settings.ACTION_MANAGE_OVERLAY_PERMISSION` with package URI.
   - Handles Android 13+ (`POST_NOTIFICATIONS`) and Android 14 (`FOREGROUND_SERVICE_SPECIAL_USE`).

2. **Foreground Service (`FloatingService.java`)**:
   - Starts via `startForegroundService()` with low-priority non-intrusive notification.
   - Instantiates `WindowManager` with `WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY` (API 26+) or `TYPE_PHONE` (legacy).
   - Draggable reticle using `OnTouchListener` with delta calculations:
     `reticleParams.x = initialX + (int)(event.getRawX() - initialTouchX)`
   - Click vs Drag threshold logic (`15px`) ensures taps expand the card while drags reposition the reticle.
   - Automatic edge snapping to the left or right screen border upon release.

3. **Floating Result Card (`floating_card.xml`)**:
   - Non-intrusive card view added dynamically to WindowManager.
   - Real search input for term definitions.
   - Asynchronous Wikipedia REST API summary fetch (`https://en.wikipedia.org/api/rest_v1/page/summary/{term}`).
   - Multilingual translation selection (Spanish, French, German, Hindi, Japanese, Chinese).
   - Screen OCR scanner trigger with context lookup.

## How to Build in Android Studio

1. Open **Android Studio** (Hedgehog, Iguana, or newer).
2. Choose **Open an Existing Project** and select this extracted directory.
3. Allow Gradle to sync dependencies (`androidx.appcompat`, `com.google.android.material`).
4. Connect an Android device or start an Android Emulator (API 26 to API 34).
5. Click **Run 'app'** (`Shift + F10`).

## Quick ADB Grant Command for Testing

If running via command line or automated test harness:
```bash
adb shell appops set com.assistant.overlay SYSTEM_ALERT_WINDOW allow
```
